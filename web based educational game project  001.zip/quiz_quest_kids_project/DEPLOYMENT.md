# Deployment Guide – Quiz Quest

## Option 1: GitHub Pages

1. Create a GitHub account.
2. Create a new repository, for example:
   quiz-quest-kids
3. Upload:
   - index.html
   - style.css
   - script.js
   - README.md
4. Open the repository's Settings.
5. Find Pages.
6. Select deployment from the main branch.
7. Save.
8. GitHub will provide a public website URL.

## Option 2: Netlify

1. Create a Netlify account.
2. Create a new site.
3. Upload the project folder or connect the GitHub repository.
4. Netlify publishes the static website.
5. Open the generated URL and test the game.

## Option 3: Vercel

1. Create a Vercel account.
2. Import the GitHub repository.
3. Select the repository containing the Quiz Quest project.
4. Deploy.
5. Open the generated deployment URL.

## Important Deployment Note

This project is a static website, so no server is required for the current version.

The leaderboard is stored using browser LocalStorage. Therefore:
- Scores are saved on the current browser/device.
- Scores are not synchronized between different users.
- Clearing browser storage can remove scores.

For a shared online leaderboard, connect the application to a backend database such as Firebase or Supabase.
