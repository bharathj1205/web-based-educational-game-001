# Quiz Quest – Kids Educational Game

## 1. Project Overview

Quiz Quest is a web-based educational game designed for children. It uses HTML5, CSS3 and JavaScript to make learning interactive and fun.

Players can choose a subject, answer multiple-choice questions, earn points, compete against previous scores and view a leaderboard.

## 2. Technologies Used

- HTML5 – page structure and semantic elements
- CSS3 – responsive design, layout, animations and styling
- JavaScript – game logic, timer, scoring, questions and leaderboard
- Browser LocalStorage – saving leaderboard data on the user's device

## 3. Educational Categories

The first version contains:
- Mathematics
- Science
- English
- General Knowledge

Each category contains 10 questions. The application randomly selects and shuffles questions and answer options.

## 4. Main Features

### Player Name
The player enters a name before starting.

### Subject Selection
The player chooses one of four educational subjects.

### Quiz System
Each game contains 10 multiple-choice questions.

### Timer
Each question has a 15-second timer.

### Scoring
A correct answer gives:
10 base points + remaining seconds.

Example:
If the player answers correctly with 8 seconds remaining:
10 + 8 = 18 points.

Wrong answers receive 0 points.

### Feedback
The application displays whether the answer is correct or incorrect and shows the correct answer when necessary.

### Result Page
At the end, the player sees:
- Total score
- Number of correct answers
- Accuracy percentage
- Star rating
- Performance message

### Leaderboard
The top 10 scores are stored using browser LocalStorage.

### Responsive Design
The interface adapts to mobile, tablet and desktop screens.

## 5. Project Structure

quiz_quest_kids/
│
├── index.html
├── style.css
├── script.js
└── README.md

## 6. How the Game Works

1. User opens index.html.
2. User enters a name.
3. User selects a subject.
4. JavaScript loads 10 questions.
5. The 15-second timer starts.
6. User selects an answer.
7. JavaScript checks the answer.
8. Score is calculated.
9. After 10 questions, final statistics are shown.
10. Score is saved to LocalStorage.
11. Leaderboard displays the top 10 scores.

## 7. Scoring Algorithm

score = 10 + remaining_time

For every correct answer:
- Base score = 10
- Time bonus = remaining seconds
- Total question score = base score + time bonus

For an incorrect answer:
- Score = 0

Maximum theoretical score per question = 25.
Maximum score for 10 questions = 250.

## 8. Data Storage

The leaderboard uses LocalStorage.

Storage key:
quizQuestLeaderboard

Example data:

[
  {
    "name": "Bharath",
    "score": 180,
    "accuracy": 80,
    "category": "Science",
    "date": "10/3/2026"
  }
]

Important: LocalStorage is browser/device based. It is not a shared online database.

## 9. Testing

Test the following:

### Functional Tests
- Name validation
- Subject selection
- Question loading
- Answer validation
- Timer countdown
- Score calculation
- Next question
- Final result
- Leaderboard saving
- Leaderboard clearing

### UI Tests
- Desktop layout
- Mobile layout
- Button visibility
- Text readability
- Responsive answer buttons

### Edge Cases
- Empty name
- Time reaches zero
- Wrong answer
- Correct answer
- Refreshing the page
- Empty leaderboard

## 10. Future Enhancements

The project can be expanded with:

- Login and registration
- Online database
- Global leaderboard
- Admin question panel
- More educational subjects
- Difficulty levels
- User profiles
- Badges and achievements
- Multiplayer mode
- Sound effects and background music
- AI-generated questions
- Progress tracking
- Parent/teacher dashboard

## 11. Limitations

The current version stores leaderboard information only in the browser's LocalStorage. Therefore, scores are not shared between different devices.

For a real production application, Firebase, Supabase or another backend/database can be integrated.

## 12. Conclusion

Quiz Quest demonstrates how HTML5, CSS3 and JavaScript can be combined to create an interactive educational application for children. The project includes educational content, game mechanics, scoring, timer functionality, responsive design and a local leaderboard.
