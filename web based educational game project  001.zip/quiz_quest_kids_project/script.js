const questionBank = {
  Math: [
    { q: "What is 5 + 7?", options: ["10", "11", "12", "13"], answer: "12", emoji: "➕" },
    { q: "What is 9 × 3?", options: ["18", "27", "21", "24"], answer: "27", emoji: "✖️" },
    { q: "What is 20 ÷ 4?", options: ["4", "5", "6", "8"], answer: "5", emoji: "➗" },
    { q: "Which number is even?", options: ["7", "11", "14", "19"], answer: "14", emoji: "🔢" },
    { q: "What is 15 - 6?", options: ["7", "8", "9", "10"], answer: "9", emoji: "➖" },
    { q: "How many sides does a triangle have?", options: ["2", "3", "4", "5"], answer: "3", emoji: "🔺" },
    { q: "What is half of 20?", options: ["5", "8", "10", "12"], answer: "10", emoji: "🍕" },
    { q: "What is 10 × 10?", options: ["10", "50", "100", "1000"], answer: "100", emoji: "💯" },
    { q: "Which is the largest number?", options: ["35", "53", "43", "33"], answer: "53", emoji: "📈" },
    { q: "How many minutes are in one hour?", options: ["30", "45", "60", "100"], answer: "60", emoji: "⏰" }
  ],
  Science: [
    { q: "Which planet is known as the Red Planet?", options: ["Earth", "Mars", "Venus", "Jupiter"], answer: "Mars", emoji: "🔴" },
    { q: "What do plants need to make food?", options: ["Sunlight", "Plastic", "Stone", "Metal"], answer: "Sunlight", emoji: "🌱" },
    { q: "Which gas do humans breathe in?", options: ["Oxygen", "Carbon dioxide", "Helium", "Hydrogen"], answer: "Oxygen", emoji: "🫁" },
    { q: "How many legs does an insect have?", options: ["4", "6", "8", "10"], answer: "6", emoji: "🐜" },
    { q: "What is H2O commonly called?", options: ["Salt", "Water", "Sugar", "Oxygen"], answer: "Water", emoji: "💧" },
    { q: "Which organ pumps blood?", options: ["Brain", "Lung", "Heart", "Stomach"], answer: "Heart", emoji: "❤️" },
    { q: "Which animal is a mammal?", options: ["Shark", "Dolphin", "Frog", "Lizard"], answer: "Dolphin", emoji: "🐬" },
    { q: "The Sun is a...", options: ["Planet", "Star", "Moon", "Comet"], answer: "Star", emoji: "☀️" },
    { q: "Which force pulls objects toward Earth?", options: ["Gravity", "Sound", "Light", "Heat"], answer: "Gravity", emoji: "🌍" },
    { q: "What part of a plant absorbs water?", options: ["Flower", "Root", "Fruit", "Leaf"], answer: "Root", emoji: "🌿" }
  ],
  English: [
    { q: "Choose the correct plural of 'child'.", options: ["Childs", "Children", "Childes", "Childrens"], answer: "Children", emoji: "📖" },
    { q: "Which word is a noun?", options: ["Run", "Beautiful", "Teacher", "Quickly"], answer: "Teacher", emoji: "📝" },
    { q: "Choose the opposite of 'hot'.", options: ["Warm", "Cold", "Big", "Fast"], answer: "Cold", emoji: "❄️" },
    { q: "Which sentence is correct?", options: ["He are happy.", "He is happy.", "He am happy.", "He be happy."], answer: "He is happy.", emoji: "✅" },
    { q: "What is the past tense of 'go'?", options: ["Goed", "Goes", "Went", "Going"], answer: "Went", emoji: "🚶" },
    { q: "Which is a vowel?", options: ["B", "E", "T", "K"], answer: "E", emoji: "🔤" },
    { q: "Choose the synonym of 'big'.", options: ["Small", "Tiny", "Large", "Short"], answer: "Large", emoji: "🐘" },
    { q: "Complete: She ___ a book.", options: ["read", "reads", "reading", "are read"], answer: "reads", emoji: "📚" },
    { q: "Which punctuation ends a question?", options: [".", ",", "?", "!"], answer: "?", emoji: "❓" },
    { q: "What is the opposite of 'early'?", options: ["Fast", "Late", "Soon", "First"], answer: "Late", emoji: "⏳" }
  ],
  General: [
    { q: "What is the capital of India?", options: ["Mumbai", "New Delhi", "Chennai", "Kolkata"], answer: "New Delhi", emoji: "🇮🇳" },
    { q: "How many days are in a week?", options: ["5", "6", "7", "8"], answer: "7", emoji: "📅" },
    { q: "Which is the largest ocean?", options: ["Atlantic", "Indian", "Pacific", "Arctic"], answer: "Pacific", emoji: "🌊" },
    { q: "Which animal is called the King of the Jungle?", options: ["Tiger", "Lion", "Elephant", "Bear"], answer: "Lion", emoji: "🦁" },
    { q: "How many colors are in a rainbow?", options: ["5", "6", "7", "8"], answer: "7", emoji: "🌈" },
    { q: "Which is the fastest land animal?", options: ["Horse", "Cheetah", "Lion", "Deer"], answer: "Cheetah", emoji: "🐆" },
    { q: "Which festival is known as the festival of lights?", options: ["Holi", "Diwali", "Pongal", "Onam"], answer: "Diwali", emoji: "🪔" },
    { q: "Which continent is India in?", options: ["Europe", "Asia", "Africa", "Australia"], answer: "Asia", emoji: "🌏" },
    { q: "How many months are in a year?", options: ["10", "11", "12", "13"], answer: "12", emoji: "🗓️" },
    { q: "Which instrument is used to measure temperature?", options: ["Barometer", "Thermometer", "Ruler", "Compass"], answer: "Thermometer", emoji: "🌡️" }
  ]
};

const state = {
  category: "",
  questions: [],
  index: 0,
  score: 0,
  correct: 0,
  timer: 15,
  interval: null,
  sound: true
};

const $ = (id) => document.getElementById(id);

const screens = {
  home: $("homeScreen"),
  quiz: $("quizScreen"),
  result: $("resultScreen"),
  leaderboard: $("leaderboardScreen")
};

function showScreen(screen) {
  Object.values(screens).forEach(s => s.classList.remove("active"));
  screens[screen].classList.add("active");
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function shuffle(array) {
  return [...array].sort(() => Math.random() - 0.5);
}

function startGame(category) {
  let name = $("playerName").value.trim();

  if (!name) {
    alert("Please enter your name first!");
    $("playerName").focus();
    return;
  }

  state.category = category;
  state.questions = shuffle(questionBank[category]).slice(0, 10);
  state.index = 0;
  state.score = 0;
  state.correct = 0;

  $("categoryLabel").textContent = category;
  $("totalQuestions").textContent = state.questions.length;
  $("scoreLabel").textContent = "0";

  showScreen("quiz");
  loadQuestion();
}

function loadQuestion() {
  clearInterval(state.interval);

  const current = state.questions[state.index];

  $("questionNumber").textContent = state.index + 1;
  $("questionText").textContent = current.q;
  $("questionEmoji").textContent = current.emoji;
  $("feedback").textContent = "";
  $("nextBtn").classList.add("hidden");
  $("progressBar").style.width =
    `${((state.index + 1) / state.questions.length) * 100}%`;

  const answers = $("answers");
  answers.innerHTML = "";

  shuffle(current.options).forEach(option => {
    const button = document.createElement("button");
    button.className = "answer-btn";
    button.textContent = option;
    button.addEventListener("click", () => checkAnswer(button, option));
    answers.appendChild(button);
  });

  startTimer();
}

function startTimer() {
  state.timer = 15;
  $("timer").textContent = state.timer;

  state.interval = setInterval(() => {
    state.timer--;
    $("timer").textContent = state.timer;

    if (state.timer <= 0) {
      clearInterval(state.interval);
      lockAnswers();
      $("feedback").textContent = "⏰ Time's up!";
      $("feedback").style.color = "#d63031";
      $("nextBtn").classList.remove("hidden");
    }
  }, 1000);
}

function checkAnswer(selectedButton, selectedAnswer) {
  clearInterval(state.interval);

  const current = state.questions[state.index];
  const buttons = document.querySelectorAll(".answer-btn");

  buttons.forEach(btn => btn.disabled = true);

  if (selectedAnswer === current.answer) {
    selectedButton.classList.add("correct");
    state.correct++;

    // Base 10 points + time bonus
    const points = 10 + state.timer;
    state.score += points;

    $("feedback").textContent = `🎉 Correct! +${points} points`;
    $("feedback").style.color = "#00a884";
    playTone("correct");
  } else {
    selectedButton.classList.add("wrong");

    buttons.forEach(btn => {
      if (btn.textContent === current.answer) {
        btn.classList.add("correct");
      }
    });

    $("feedback").textContent = `❌ Not quite! Correct answer: ${current.answer}`;
    $("feedback").style.color = "#d63031";
    playTone("wrong");
  }

  $("scoreLabel").textContent = state.score;
  $("nextBtn").classList.remove("hidden");
}

function lockAnswers() {
  const buttons = document.querySelectorAll(".answer-btn");
  const current = state.questions[state.index];

  buttons.forEach(btn => {
    btn.disabled = true;
    if (btn.textContent === current.answer) {
      btn.classList.add("correct");
    }
  });
}

function nextQuestion() {
  if (state.index < state.questions.length - 1) {
    state.index++;
    loadQuestion();
  } else {
    finishGame();
  }
}

function finishGame() {
  clearInterval(state.interval);

  const total = state.questions.length;
  const accuracy = Math.round((state.correct / total) * 100);

  $("finalScore").textContent = state.score;
  $("correctCount").textContent = `${state.correct}/${total}`;
  $("accuracy").textContent = `${accuracy}%`;

  let starCount = 1;
  if (accuracy >= 80) starCount = 3;
  else if (accuracy >= 50) starCount = 2;

  $("stars").textContent = "⭐".repeat(starCount);

  if (accuracy >= 80) {
    $("resultMessage").textContent = "Amazing! You are a Quiz Champion! 🌟";
  } else if (accuracy >= 50) {
    $("resultMessage").textContent = "Great work! Keep learning and improving! 💪";
  } else {
    $("resultMessage").textContent = "Good try! Practice makes you better! 📚";
  }

  saveScore(state.score, accuracy);
  showScreen("result");
  playTone("finish");
}

function saveScore(score, accuracy) {
  const name = $("playerName").value.trim() || "Player";

  const leaderboard = JSON.parse(
    localStorage.getItem("quizQuestLeaderboard") || "[]"
  );

  leaderboard.push({
    name,
    score,
    accuracy,
    category: state.category,
    date: new Date().toLocaleDateString()
  });

  leaderboard.sort((a, b) => b.score - a.score);

  localStorage.setItem(
    "quizQuestLeaderboard",
    JSON.stringify(leaderboard.slice(0, 10))
  );
}

function showLeaderboard() {
  const list = $("leaderboardList");
  const leaderboard = JSON.parse(
    localStorage.getItem("quizQuestLeaderboard") || "[]"
  );

  if (leaderboard.length === 0) {
    list.innerHTML = "<p>No scores yet. Play a game to become the first champion! 🚀</p>";
  } else {
    list.innerHTML = leaderboard.map((entry, index) => `
      <div class="leader-row">
        <div class="leader-rank">${index === 0 ? "🥇" : index === 1 ? "🥈" : index === 2 ? "🥉" : index + 1}</div>
        <div>
          <div class="leader-name">${escapeHTML(entry.name)}</div>
          <div class="leader-category">${escapeHTML(entry.category)} • ${entry.accuracy}% • ${entry.date}</div>
        </div>
        <div class="leader-score">${entry.score} pts</div>
      </div>
    `).join("");
  }

  showScreen("leaderboard");
}

function escapeHTML(text) {
  return text.replace(/[&<>"']/g, char => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#039;"
  }[char]));
}

function playTone(type) {
  if (!state.sound) return;

  try {
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    if (!AudioContext) return;

    const ctx = new AudioContext();
    const oscillator = ctx.createOscillator();
    const gain = ctx.createGain();

    oscillator.connect(gain);
    gain.connect(ctx.destination);

    oscillator.frequency.value =
      type === "correct" ? 700 :
      type === "wrong" ? 180 : 900;

    gain.gain.value = 0.05;
    oscillator.start();

    setTimeout(() => {
      oscillator.stop();
      ctx.close();
    }, 120);
  } catch (error) {
    // Sound is optional; game continues without it.
  }
}

document.querySelectorAll(".category-btn").forEach(button => {
  button.addEventListener("click", () => {
    startGame(button.dataset.category);
  });
});

$("nextBtn").addEventListener("click", nextQuestion);

$("playAgainBtn").addEventListener("click", () => {
  startGame(state.category);
});

$("leaderboardHomeBtn").addEventListener("click", showLeaderboard);
$("leaderboardResultBtn").addEventListener("click", showLeaderboard);

$("homeBtn").addEventListener("click", () => showScreen("home"));
$("leaderboardBackBtn").addEventListener("click", () => showScreen("home"));

$("clearBoardBtn").addEventListener("click", () => {
  const confirmClear = confirm("Clear all leaderboard scores?");
  if (confirmClear) {
    localStorage.removeItem("quizQuestLeaderboard");
    showLeaderboard();
  }
});

$("soundBtn").addEventListener("click", () => {
  state.sound = !state.sound;
  $("soundBtn").textContent = state.sound ? "🔊" : "🔇";
});
