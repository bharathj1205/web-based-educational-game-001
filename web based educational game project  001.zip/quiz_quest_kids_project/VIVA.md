# Viva / Presentation Preparation

## Project Title
Quiz Quest – Kids Educational Game

## Problem Statement
Traditional learning can sometimes be less engaging for children. This project provides an interactive quiz-based learning environment where children can learn concepts while playing.

## Objective
The main objective is to develop a simple and attractive educational game using front-end web technologies.

## Why HTML5?
HTML5 provides the structure and semantic elements required for the web application.

## Why CSS3?
CSS3 is used for responsive layout, colors, buttons, cards, animations and mobile support.

## Why JavaScript?
JavaScript controls the game logic, questions, timer, score calculation, result generation and leaderboard.

## Why LocalStorage?
LocalStorage allows the browser to save leaderboard data without requiring a backend server.

## What is the main advantage?
The application combines education and game mechanics to make learning interactive.

## Common Viva Questions

### 1. What is the project?
It is a web-based educational quiz game for children.

### 2. Which technologies are used?
HTML5, CSS3 and JavaScript.

### 3. How is the score calculated?
For every correct answer, the player gets 10 base points plus the remaining timer seconds.

### 4. How is leaderboard data stored?
It is stored in browser LocalStorage.

### 5. Is the leaderboard global?
No. The current version is local to the browser/device.

### 6. How can it become a real online leaderboard?
A backend database such as Firebase or Supabase can be integrated.

### 7. Is the website responsive?
Yes. CSS media queries adapt the layout for smaller screens.

### 8. What happens when the timer reaches zero?
The answer buttons are locked and the player can move to the next question.

### 9. What are future improvements?
Login, global leaderboard, database, admin panel, difficulty levels, badges and teacher/parent dashboard.

### 10. What did you learn from the project?
DOM manipulation, JavaScript events, arrays and objects, LocalStorage, responsive CSS, validation and deployment of a static website.
